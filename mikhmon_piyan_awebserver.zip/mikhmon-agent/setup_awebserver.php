<?php
$msg = "";
if (isset($_POST["run_setup"])) {
    try {
        $pdo = new PDO("mysql:host=127.0.0.1;charset=utf8mb4", "root", "", [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS mikhmon_piyan CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE mikhmon_piyan");
        $sqls = ["database/complete_installation.sql", "database/agent_system.sql", "database/billing_module.sql", "database/payment_gateway_tables.sql", "database/public_sales_schema.sql", "database/safe_fix_tables.sql"];
        foreach ($sqls as $sf) {
            if (file_exists(__DIR__ . "/" . $sf)) {
                try { $pdo->exec(file_get_contents(__DIR__ . "/" . $sf)); } catch (Exception $e) {}
            }
        }
        $hash = password_hash("1510", PASSWORD_DEFAULT);
        try { $pdo->exec("UPDATE admin SET username='piyan', password='$hash'"); } catch (Exception $e) {}
        $msg = "<div style='background:#064e3b;color:#6ee7b7;padding:12px;border-radius:8px;margin-bottom:14px;font-weight:700'>SUKSES! Database siap. Login: <u>piyan</u> | Password: <u>1510</u></div>";
    } catch (Exception $e) {
        $msg = "<div style='background:#7f1d1d;color:#fca5a5;padding:12px;border-radius:8px;margin-bottom:14px'>Error MariaDB/MySQL: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}
?>
<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup DB - PIYAN HOTSPOT</title></head>
<body style="background:#0b1120;color:#f8fafc;font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:16px">
<div style="background:#1e293b;padding:24px;border-radius:14px;max-width:420px;width:100%;border:1px solid #334155">
  <h2 style="margin:0 0 8px;color:#38bdf8">Setup Database Otomatis</h2>
  <p style="font-size:13px;color:#94a3b8;margin:0 0 16px">Berlaku untuk <b>AWebServer (Android)</b> & <b>XAMPP/Laragon (PC)</b>. Pastikan layanan MySQL/MariaDB sudah aktif.</p>
  <?= $msg ?>
  <form method="POST"><button name="run_setup" style="width:100%;padding:12px;background:#0284c7;color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer">Install Database Sekarang</button></form>
  <div style="margin-top:14px;text-align:center"><a href="index.php" style="color:#38bdf8;text-decoration:none;font-size:13px">Ke Halaman Login &rarr;</a></div>
</div></body></html>