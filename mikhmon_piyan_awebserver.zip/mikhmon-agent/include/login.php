<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login - PIYAN HOTSPOT</title>
<style>
  *{box-sizing:border-box;font-family:system-ui,-apple-system,sans-serif;margin:0;padding:0}
  body{min-height:100vh;background:radial-gradient(circle at top right,#0f172a,#020617);display:flex;align-items:center;justify-content:center;padding:16px;color:#f8fafc}
  .box{width:100%;max-width:380px;background:rgba(30,41,59,0.88);backdrop-filter:blur(14px);border:1px solid rgba(56,189,248,0.3);border-radius:18px;padding:28px 24px;box-shadow:0 20px 45px rgba(0,0,0,0.6)}
  .logo{width:54px;height:54px;border-radius:14px;background:linear-gradient(135deg,#0284c7,#38bdf8);display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:24px;font-weight:900;color:#fff}
  h2{text-align:center;font-size:20px;font-weight:800;color:#fff}
  .sub{text-align:center;font-size:12px;color:#94a3b8;margin:4px 0 20px}
  label{display:block;font-size:11px;font-weight:700;color:#cbd5e1;margin-bottom:5px;text-transform:uppercase}
  input{width:100%;padding:12px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#fff;font-size:14px;margin-bottom:14px;outline:none}
  input:focus{border-color:#38bdf8}
  button{width:100%;padding:13px;background:linear-gradient(135deg,#0284c7,#2563eb);color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:800;cursor:pointer}
  .err{background:rgba(220,38,38,0.2);border:1px solid #ef4444;color:#fca5a5;padding:10px;border-radius:8px;font-size:12px;text-align:center;margin-bottom:14px}
  .links{margin-top:16px;padding-top:12px;border-top:1px solid #334155;display:flex;justify-content:space-between;font-size:11px}
  .links a{color:#38bdf8;text-decoration:none;font-weight:600}
</style>
</head>
<body>
<div class="box">
  <div class="logo">P</div><h2>PIYAN HOTSPOT</h2><div class="sub">Billing & MikroTik Manager</div>
  <?php if (!empty($error)) echo "<div class='err'>$error</div>"; ?>
  <form method="POST"><label>Username</label><input type="text" name="user" placeholder="piyan" required autofocus><label>Password</label><input type="password" name="pass" placeholder="••••" required><button type="submit" name="login">MASUK PANEL</button></form>
  <div class="links"><a href="setup_awebserver.php">1. Setup Database</a><a href="agent-admin/login.php">Panel Admin &rarr;</a></div>
</div>
</body>
</html>